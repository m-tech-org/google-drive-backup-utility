#!/bin/bash
sudo systemctl start gdrive-backup-utility.service

