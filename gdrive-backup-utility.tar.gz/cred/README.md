# Credentials Setup (Required)

Ensure that you have completed the setup `steps 3` in [README.md](../README.md).

To enable Google Drive uploads, you must place your Google Drive API credential files in the `cred/` directory.

## Instructions:

1. Create a folder named cred in the project root (if it does not already exist).
2. Download your Google OAuth credentials file from Google Cloud Console.
3. Copy the downloaded file and rename it to:

    ```
    credentials.json
    ```

4. After the first successful authentication, Google will automatically generate:

    ```
    token.json
    ```

5. Place both files inside the `cred/` directory:

    ```
        cred/
        ├── credentials.json
        ├── README.md
        ├── token.json
    ```
## Important Notes

* `credentials.json` is mandatory before the first run.

* `token.json` will be created automatically after you authorize access in the browser.

* Do not delete `token.json` unless you want to re-authenticate.

* Keep these files private and never commit them to version control.

Once the credentials are in place, the backup service can securely upload files to your Google Drive.

Now goto [README.md](../README.md) and follow steps 5