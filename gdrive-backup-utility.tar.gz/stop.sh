#!/bin/bash
sudo systemctl stop gdrive-backup-utility.service

