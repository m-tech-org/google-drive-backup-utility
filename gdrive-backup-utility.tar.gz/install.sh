#!/bin/bash
mkdir -p "$PWD/log"
chmod +x  run.sh uninstall.sh start.sh stop.sh
SERVICE_CONTENT="[Unit]
Description=Python Backup Service with Google Drive
After=network.target
[Service]
User=$USER
WorkingDirectory=$PWD
ExecStart=$PWD/run.sh
Restart=always
RestartSec=5
StandardOutput=append:$PWD/log/service.log
StandardError=append:$PWD/log/service-error.log
[Install]
WantedBy=multi-user.target"

echo "$SERVICE_CONTENT" | sudo tee /etc/systemd/system/gdrive-backup-utility.service > /dev/null

sudo systemctl daemon-reload
sudo systemctl enable gdrive-backup-utility.service
echo "Service installed. Run start.sh to start and stop.sh to stop the service."

