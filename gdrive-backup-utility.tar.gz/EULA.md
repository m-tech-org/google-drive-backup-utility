# End User License Agreement (EULA)
### Copyright (c) 2026 M-Tech. All rights reserved.
### Effective Date: January, 2026

This End User License Agreement (“Agreement”) is a legal agreement between you (“User”) and the Author (“Licensor”) for the use of this software product (“Software”).

By purchasing, installing, or using the Software, you agree to be bound by this Agreement.

## 1. License Grant

Upon payment of the applicable subscription fee, Licensor grants you a:

Non-exclusive

Non-transferable

Non-sublicensable

Time-limited license

to use the Software for personal or internal business purposes during the active subscription period.

## 2. Subscription Model

The Software is licensed on a subscription basis.

The license remains valid only for the purchased duration.

When the subscription expires, the license automatically terminates.

Continued usage requires renewal.

Expired licenses may result in restricted or disabled functionality.

## 3. Restrictions

You may NOT:

Reverse engineer, decompile, or disassemble the Software.

Modify or create derivative works.

Redistribute, resell, lease, rent, or sublicense.

Share or expose license keys.

Bypass or tamper with license verification mechanisms.

Use the Software for unlawful purposes.

Violation of these restrictions may result in immediate termination without refund.

## 4. Intellectual Property

The Software and all associated intellectual property rights remain the exclusive property of the Licensor.

This Agreement does not transfer ownership.

## 5. Updates and Support

Active subscribers may receive:

Bug fixes

Security patches

Feature updates (if applicable)

Technical support (if included in the subscription plan)

Support and updates are available only during an active subscription.

## 6. Termination

This Agreement terminates automatically when:

The subscription expires

The user violates any term of this Agreement

Upon termination, you must cease all use of the Software.

## 7. Disclaimer of Warranty

The Software is provided “AS IS”, without warranty of any kind, express or implied.

The Licensor disclaims all warranties including merchantability and fitness for a particular purpose.

## 8. Limitation of Liability

In no event shall the Licensor be liable for:

Indirect damages

Data loss

Business interruption

Loss of profits

Total liability shall not exceed the amount paid for the subscription.

## 9. Governing Law

This Agreement shall be governed by the laws of the applicable jurisdiction of the Licensor.