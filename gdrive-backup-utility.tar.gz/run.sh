#!/bin/bash
PROJECT_DIR="$(pwd)"
RUN_SCRIPT="gdrive-backup-utility"
TOKEN_FILE="$PROJECT_DIR/token.txt"
if [ ! -f "$TOKEN_FILE" ]; then
  echo "Executing $RUN_SCRIPT for authentication"
  ./"$RUN_SCRIPT"
  exit 0
fi
echo "Starting Google Drive Backup Service..."
exec ./"$RUN_SCRIPT"

