# M-Tech Software License Agreement

### Copyright (c) 2026 M-Tech. All rights reserved.

## 1. Grant of License
M-Tech grants you a non-exclusive, non-transferable, limited license to use the GD Backup Utility (the "Software") solely for your internal business or personal operations, subject to the terms of your active subscription.

## 2. Subscription & Validation
License Key: Usage of this Software requires a valid License Key issued by M-Tech or its authorized partners.

Validation: The Software includes a "phone-home" mechanism to verify subscription status. You agree to allow the Software to communicate with M-Tech’s licensing servers for this purpose.

Termination: If your subscription expires or is canceled, the license is automatically revoked, and the Software may cease to function.

## 3. Restrictions
You may not:

Decompile, reverse engineer, or attempt to derive the source code from the compiled binary.

Redistribute, sell, lease, or sublicense the Software to third parties without prior written consent from M-Tech.

Modify or remove any proprietary notices or labels on the Software.

## 4. No Warranty
THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES, OR OTHER LIABILITY, INCLUDING DATA LOSS, ARISING FROM THE USE OF THE SOFTWARE.

## 5. Support
Support is provided to active subscribers only via mtechltd2021@gmail.com.