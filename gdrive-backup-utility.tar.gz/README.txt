================================================================================
APPLICATION DEPLOYMENT INSTRUCTIONS
================================================================================

SETUP:
------
1. Check README.md in 'doc' directory

2. Edit .env with your actual configuration values:
   nano .env  (or use any text editor)

3. Make the executable runnable (Linux only):
   chmod +x install.sh

5. To test the service execute: ./run.sh

5. For installing the service execute: ./install.sh

RUNNING AND STOPPING THE APPLICATION:
------------------------
1. To start the service execute: ./start.sh
1. To Stop the service execute: ./stop.sh

CONFIGURATION:
--------------
All configuration is done through the .env file.

TROUBLESHOOTING:
----------------
- If the app can't find .env, make sure it's in the same directory as the executable
- Check file permissions on Linux
- Ensure all required environment variables are set in .env

For support, contact: mtechltd2021@gmail.com
================================================================================
