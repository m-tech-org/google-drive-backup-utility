#!/bin/bash
SERVICE_NAME="gdrive-backup-utility.service"
SERVICE_PATH="/etc/systemd/system/$SERVICE_NAME"
echo "Stopping and uninstalling $SERVICE_NAME..."
if systemctl is-active --quiet "$SERVICE_NAME"; then
    echo "Stopping active service..."
    sudo systemctl stop "$SERVICE_NAME"
fi
if systemctl is-enabled --quiet "$SERVICE_NAME"; then
    echo "Disabling service boot trigger..."
    sudo systemctl disable "$SERVICE_NAME"
fi
if [ -f "$SERVICE_PATH" ]; then
    echo "Removing service file: $SERVICE_PATH"
    sudo rm "$SERVICE_PATH"
fi
echo "Reloading systemd daemon..."
sudo systemctl daemon-reload
sudo systemctl reset-failed
echo "-----------------------------------------------"
echo "Uninstall complete. The service has been removed."
echo "-----------------------------------------------"
