# HOW TO GET TOKEN FOR GOOGLE DRIVE API 

Ensure that you have completed the setup `steps 2` in [README.md](../README.md).

## Instructions:

1. Run the `gdrive-backup-utility` using the following command
   ```
   ./gdrive-backup-utility
   ```
2. A browser window will open, prompting you to log in to your Google account and grant access to the application.
3. After granting access, the browser window will close, and the terminal will display the token information.
4. Token information will be saved in the `token.json` file.
5. Now follow steps 4 in [README.md](../README.md) for further instructions.