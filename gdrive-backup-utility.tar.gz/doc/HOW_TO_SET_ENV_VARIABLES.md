# How to set environment variables

Copy `.env.example` file to `.env` file.

## Instructions:

Set value for the below variable in `.env` file:

1. `GDRIVE_FOLDER_ID` => Google Drive Folder ID (mandatory)
2. `SOURCE_DIRECTORY` => path to directory containing files to upload.
3. `COMPRESS_ENABLE` => true | false (mandatory)
4. `COMPRESSION_FORMAT` => zip | tar.gz
5. `COMPRESSED_FILE_PATTERN` => *.zip | *.tar.gz
6. `TEMP_DIRECTORY` => path for tmp zip files (mandatory)
7. `REMOVE_OLD_BACKUPS` => true | false (mandatory)
8. `DB_BACKUP_ENABLE`=> true | false (mandatory)
9. `SQL_COMMAND` => mysqldump | pg_dump | mariadb-dump (mandatory)
10. `DB_USER` => database user (mandatory)
11. `DB_PASS` => database password (mandatory)
12. `DB_NAME` => database name (mandatory)
13. `DB_BACKUP_OUTPUT` => same as `TEMP_DIRECTORY` (mandatory)