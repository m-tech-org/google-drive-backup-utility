# How TO Download Credentials for Google Drive API

Ensure that you have completed the setup `steps 1` in [README.md](../README.md).

## Instructions:
1. Go to the [Google Cloud Console](https://console.cloud.google.com/).
2. Create a new project or select an existing one.
3. Enable Google Drive API.
4. Navigate to the "APIs & Services" section and click on **Credentials**.
5. Click on **Create Credentials** and select **OAuth client ID**.
6. Choose **Desktop app** as the application type and give it a name.
7. Click **Create** and download the JSON file.
8. Change Test to Publish in the Audience section.
9. Rename the downloaded file to `credentials.json`.
10. Place the `credentials.json` file in the `cred/` directory of your project.
11. Follow steps 3 in [README.md](../README.md) for further setup.