# HOW TO RUN

Ensure that you have completed the setup `steps 4` in [README.md](../README.md).

## Instruction:

1. Run the following command to start the `gdrive-backup-utility`:
   ```
   ./gdrive-backup-utility
   ```
2. The service will start and begin backing up files to Google Drive.
3. Check the logs for any errors or warnings.
4. Verify that the backups are being uploaded to the specified Google Drive folder.
