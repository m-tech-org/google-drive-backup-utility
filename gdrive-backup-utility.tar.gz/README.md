# Google Drive Upload Script

## Instructions:

1. To set environment variables, refer to [HOW_TO_SET_ENV_VARIABLES.md](doc/HOW_TO_SET_ENV_VARIABLES.md).
2. To get `credentials.json`, follow the steps in [HOW_TO_DOWNLOAD_CREDENTIALS.md](doc/HOW_TO_DOWNLOAD_CREDENTIALS.md).
3. To get `token.json`, follow the steps in [HOW_TO_GET_TOKEN.md](doc/HOW_TO_GET_TOKEN.md).
4. To set up the **credentials**, follow the steps in [README.md](cred/README.md) in cred folder.
5. To run the project, follow the steps in [HOW_TO_RUN.md](doc/HOW_TO_RUN.md).

## 🔐 License

This project is distributed under a commercial subscription license.

Purchasing a license allows you to use the software during the active subscription period only.

See [EULA.md](EULA.md) for full terms.